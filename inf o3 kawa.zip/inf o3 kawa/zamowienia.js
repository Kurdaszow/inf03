function zamowienia(){
var numer=document.getElementById('numer').value;
var waga=document.getElementById('waga').value;
if(numer==1){
document.getElementById('A').innerHTML = "Koszt zamówienia to: " + waga*5 + 'zl';
}
if(numer==1){
    document.getElementById('A').innerHTML = "Koszt zamówienia to: " + waga*5 + 'zl';
    }
else  if(numer==2){
        document.getElementById('A').innerHTML = "Koszt zamówienia to: " + waga*7 + 'zl';
        }
 else  if(numer==3){
         document.getElementById('A').innerHTML = "Koszt zamówienia to: " + waga*6 + 'zl';
            }
else  if(numer>3){
        document.getElementById('A').innerHTML = "Koszt zamówienia to: " + waga*0 + 'zl';
        }
else  if(numer<1){
            document.getElementById('A').innerHTML = "Koszt zamówienia to: " + waga*0 + 'zl';
            }
}