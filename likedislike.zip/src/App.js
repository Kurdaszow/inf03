import React, { useState } from "react";
import { BiUserCircle } from "react-icons/bi";
import { AiOutlineHeart, AiFillHeart } from "react-icons/ai";

function App(){
  const[like, setLike] = useState(false);
  const[count, setCount] = useState(5);
  const[show, setShow] = useState(true);

  const[like2, setLike2] = useState(false);
  const[count2, setCount2] = useState(17);
  const[show2, setShow2] = useState(true);

  const[like3, setLike3] = useState(false);
  const[count3, setCount3] = useState(3);
  const[show3, setShow3] = useState(true);


  const handlelikes = () => {
    if (!like) {
      setLike(true);
      setCount(count + 1);
    } else {
      setLike(false);
      setCount(count-1);
    }
  };

  const handlelikes2 = () => {
    if (!like2) {
      setLike2(true);
      setCount2(count2 + 1);
    } else {
      setLike2(false);
      setCount2(count2-1);
    }
  };

  const handlelikes3 = () => {
    if (!like3) {
      setLike3(true);
      setCount3(count3 + 1);
    } else {
      setLike3(false);
      setCount3(count3-1);
    }
  };

  const imageUrl = "img";

  return (
    <div className="main-container">


      <div className="przyklad1">
        <h1>First Title</h1>
        <div className="likeandbut">
          <h4>{count}</h4>
          <button type="button" onClick={() => {
           setShow(!show);
            handlelikes();
         }}>
           {show === true ? 'Like' : 'Dislike'}
         </button>
        </div>
      </div>
      <div className="przyklad2">
        <h1>Seconds Title</h1>
        <div className="likeandbut">
          <h4>{count2}</h4>
          <button type="button" onClick={() => {
           setShow2(!show);
            handlelikes2();
         }}>
           {show2 === true ? 'Like' : 'Dislike  '}
         </button>
        </div>
      </div>
      <div className="przyklad3">
        <h1>Third Title</h1>
        <div className="likeandbut">
          <h4>{count3}</h4>
          <button type="button" onClick={() => {
           setShow3(!show3);
            handlelikes3();
         }}>
           {show3 === true ? 'Like' : 'Dislike'}
         </button>
        </div>
      </div>
      
    </div>
  );
}

export default App;